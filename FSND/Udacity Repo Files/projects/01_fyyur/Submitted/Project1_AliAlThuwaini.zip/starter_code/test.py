
import json
import dateutil.parser
import babel
from flask import Flask, render_template, request, Response, flash, redirect, url_for
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy
import logging
from logging import DEBUG, Formatter, FileHandler
from flask_wtf import Form
from forms import *

#Ali:
from flask_migrate import Migrate, current # Enable db Migration
from sqlalchemy.orm import backref # Enable db 

app = Flask(__name__)
moment = Moment(app)
app.config.from_object('config')
db = SQLAlchemy(app)




class Venue(db.Model):
  __tablename__ = 'venues'

  id = db.Column(db.Integer, primary_key=True)
  name = db.Column(db.String, nullable=False)
  city = db.Column(db.String(120))
  state = db.Column(db.String(120))
  address = db.Column(db.String)
  phone = db.Column(db.String(120))
  image_link = db.Column(db.String)
  facebook_link = db.Column(db.String)
  #Ali: adding the missing columns
  website = db.Column(db.String)
  seeking_talent = db.Column(db.Boolean)
  seeking_description = db.Column(db.String)
  genres = db.Column(db.ARRAY(db.String))

  #setting up the relationship:
  show = db.relationship('Show', backref= 'venue', lazy=True)




  # define dunder repr method to help in db troubleshooting
  def __repr__(self):
    return f'<Venue_id: {self.id}, Vendue_name: {self.name}>'


class Artist(db.Model):
  __tablename__ = 'artists'

  id = db.Column(db.Integer, primary_key=True)
  name = db.Column(db.String, nullable=False)
  city = db.Column(db.String(120))
  state = db.Column(db.String(120))
  phone = db.Column(db.String(120))
  genres = db.Column(db.ARRAY(db.String))
  image_link = db.Column(db.String, nullable=False)
  facebook_link = db.Column(db.String)
  #Ali: adding the missing columns
  website = db.Column(db.String)
  seeking_venue = db.Column(db.Boolean)
  seeking_description = db.Column(db.String)

  #setting up the relationship:
  show = db.relationship('Show', backref= 'artist', lazy=True)

  def __repr__(self):
    return f'<Artist_id: {self.id}, Artist_name: {self.name}>'



class Show(db.Model):
  __tablename__ = 'shows'
  id = db.Column(db.Integer, primary_key=True)

  #if default did not work, try: datetime.dateime.utcnow
  start_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

  # reltionships:
  venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
  artist_id = db.Column(db.Integer, db.ForeignKey('artists.id'), nullable=False)


  def __repr__(self):
    return f'<Show_id: {self.id}, Venue_id: {self.venue_id}, Artist_id: {self.artist_id}>'

#----------------------------------------------------------------------------#
# Filters.
#----------------------------------------------------------------------------#

searchedArtist = request.form.get('search_term', '')
#query db for artist.name containing that serach word
artists = Artist.query.filter(Artist.name.ilike(f'%{searchedArtist}%')).all()
print (artists)
data = []

for artist in artists:
    data.append({
        "id": artist.id,
        "name": artist.name,
        "num_upcoming_shows": len(db.session.query(Show).filter(Show.artist_id == artist.id).filter(Show.start_time > datetime.now()).all()),
    })

    print ('artist', artist)

response={
"count": len(artists),
"data": data
}

print ('response: ', response)